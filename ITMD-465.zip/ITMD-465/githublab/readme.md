<h1> Arthur Arreguin</h1>

<h2>ITMD-465-Fall 2018</h2>

<h2>Academic Interests</h2>

<h3>Github Lab</h3>
<h3> In this lab assigment, I created a node.js package that prints to the console of a system with the title hello world including my name as well.</h3>
<h3>The purporse of this is just to get a hang of how node.js functions. it also envolves using git and github to push towards the repository</h3>