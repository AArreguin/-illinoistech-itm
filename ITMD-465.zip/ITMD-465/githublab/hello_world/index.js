// JavaScript source code
console.log("Hello Arthur Arreguin");